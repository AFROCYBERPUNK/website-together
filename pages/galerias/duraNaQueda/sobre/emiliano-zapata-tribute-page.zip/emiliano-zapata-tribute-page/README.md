# Emiliano Zapata tribute page

A Pen created on CodePen.io. Original URL: [https://codepen.io/berny12/pen/aZzNvG](https://codepen.io/berny12/pen/aZzNvG).

esta es una pequeña paguina tributo a Emiliano 
Zapata